setwd("C:\\Users\\dewmi\\Desktop\\IT24101451")


set.seed(123)
baking_time <- rnorm(25, mean = 45, sd = 2)
baking_time


t.test(baking_time, mu = 46, alternative = "less")
