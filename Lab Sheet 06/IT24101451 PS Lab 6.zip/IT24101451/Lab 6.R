setwd("C:\\Users\\dewmi\\Desktop\\IT24101451 Lab 6")

1-pbinom(46,50,0.85)

dpois(15,12)
