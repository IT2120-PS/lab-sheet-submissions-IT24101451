setwd("C:\\Users\\dewmi\\Desktop\\IT24101451")
data<-read.table("Exercise - LaptopsWeights.txt", header = TRUE)
fix(data)
attach(data)

#Question 1
popmean <- mean(Weight.kg.)
popsd   <- sd(Weight.kg.) * sqrt((length(Weight.kg.)-1)/length(Weight.kg.))

popmean
popsd

#Question 2
n.means <- c()
n.sds   <- c()

for (i in 1:25) {
  samp <- sample(Weight.kg., size=6, replace=TRUE)
  n.means[i] <- mean(samp)
  n.sds[i]   <- sd(samp)
}

n.means
n.sds

#Question 3
samplemean_mean <- mean(n.means)
samplemean_sd   <- sd(n.means)

samplemean_mean
samplemean_sd